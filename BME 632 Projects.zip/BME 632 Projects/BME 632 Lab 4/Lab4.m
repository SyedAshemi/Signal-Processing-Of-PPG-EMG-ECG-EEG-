%% PART 1)
%a)
filt = designfilt('bandpassiir','FilterOrder',8, ...
'PassbandFrequency1',0.5,'PassbandFrequency2',22, ...
'SampleRate',500);
fvtool(filt,Analysis="freq");

%% PART 2)
dataOpen = readtable("eyesopen.csv");
dataClosed = readtable("eyesclosed.csv");
openO1 = dataOpen(:,4);
openO1 = openO1{:,:};
openO2 = dataOpen(:,5);
openO2 = openO2{:,:};
topen = dataOpen(:,1);
topen = topen{:,:};
topen = (0:length(topen)-1);
topen = topen*0.002;
closedO1 = dataClosed(:,4);
closedO1 = closedO1{:,:};
closedO2 = dataClosed(:,5);
closedO2 = closedO2{:,:};
tclosed = dataClosed(:,1);
tclosed = tclosed{:,:};
tclosed = (0:length(tclosed)-1);
tclosed = tclosed*0.002;
filteredOpenO1 = filter(filt,openO1);
filteredOpenO2 = filter(filt,openO2);
filteredClosedO1 = filter(filt,closedO1);
filteredClosedO2 = filter(filt,closedO2);

figure(2)
subplot(4,1,1)
plot(topen,openO1)
xlim([30,90])
title("Unfiltered O1 and O2 plots for Eyes Open")
xlabel("Time(s)")
ylabel("Voltage(uV)")
subplot(4,1,2)
plot(topen,openO2)
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90])
subplot(4,1,3)
plot(topen,filteredOpenO1)
title("Filtered O1 and O2 plots for Eyes Open")
xlabel("Time(s)")
ylabel("Voltage(uV)")
subplot(4,1,4)
plot(topen,filteredOpenO2)
xlabel("Time(s)")

ylabel("Voltage(uV)")
figure(3)
subplot(411)
plot(tclosed,closedO1)
xlim([30,90])
title("Unfiltered O1 and O2 plots for Eyes Closed")
xlabel("Time(s)")
ylabel("Voltage(uV)")
subplot(412)
plot(tclosed,closedO2)
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90])
subplot(413)
plot(tclosed,filteredClosedO1)
xlim([30,90])
title("Filtered O1 and O2 plots for Eyes Closed")
xlabel("Time(s)")
ylabel("Voltage(uV)")
subplot(414)
plot(tclosed,filteredClosedO2)
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90])

%% Part 3)
%Alpha
alpha = designfilt('bandpassiir','FilterOrder',8, ...
'PassbandFrequency1',8,'PassbandFrequency2',13, ...
'SampleRate',500);
fvtool(alpha,Analysis="freq");
%Beta
beta = designfilt('bandpassiir','FilterOrder',8, ...
'PassbandFrequency1',13,'PassbandFrequency2',22, ...
'SampleRate',500);
fvtool(beta,Analysis="freq");
%Delta
delta = designfilt('bandpassiir','FilterOrder',8, ...
'PassbandFrequency1',0.5,'PassbandFrequency2',4, ...
'SampleRate',500);
fvtool(delta,Analysis="freq");
%Theta
theta = designfilt('bandpassiir','FilterOrder',8, ...
'PassbandFrequency1',4,'PassbandFrequency2',8, ...
'SampleRate',500);
fvtool(theta,Analysis="freq");

%% Part 4) Eyes Open
openfp1 = dataOpen(:,2);
openfp1 = openfp1{:,:};
openfp2 = dataOpen(:,3);
openfp2 = openfp2{:,:};
filteredOpenfp1 = filter(filt,openfp1);
filteredOpenfp2 = filter(filt,openfp2);

%Open O1 Filtered
alphaOpenO1 = filter(alpha,filteredOpenO1);
betaOpenO1 = filter(beta,filteredOpenO1);
deltaOpenO1 = filter(delta,filteredOpenO1);
thetaOpenO1 = filter(theta,filteredOpenO1);

%Plot of O1 Waves for Eyes Open
figure(4);
subplot(4,1,1);
plot(topen,alphaOpenO1);
title("Alpha Wave Open O1");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([0.3,0.9]);
subplot(4,1,2);
plot(topen,betaOpenO1);
title("Beta Wave Open O1");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([0.3,0.9]);
subplot(4,1,3);
plot(topen,deltaOpenO1);
title("Delta Wave Open O1");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([0.3,0.9]);
subplot(4,1,4);
plot(topen,thetaOpenO1);
title("Theta Wave Open O1");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([0.3,0.9]);

%Open O2 Filtered
alphaOpenO2 = filter(alpha,filteredOpenO2);
betaOpenO2 = filter(beta,filteredOpenO2);
deltaOpenO2 = filter(delta,filteredOpenO2);
thetaOpenO2 = filter(theta,filteredOpenO2);

%Plot of O2 Waves for Eyes Open
figure(5);
subplot(4,1,1);
plot(topen,alphaOpenO2);
title("Alpha Wave Open O2");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([0.3,0.9]);
subplot(4,1,2);
plot(topen,betaOpenO2);
title("Beta Wave Open O2");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([0.3,0.9]);
subplot(4,1,3);
plot(topen,deltaOpenO2);
title("Delta Wave Open O2");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([0.3,0.9]);
subplot(4,1,4);
plot(topen,thetaOpenO2);
title("Theta Wave Open O2");
xlabel("Time(s)")
xlim([0.3,0.9]);
ylabel("Voltage(uV)")

%Open FP1 Filtered
alphaOpenfp1 = filter(alpha,filteredOpenfp1);
betaOpenfp1 = filter(beta,filteredOpenfp1);
deltaOpenfp1 = filter(delta,filteredOpenfp1);
thetaOpenfp1 = filter(theta,filteredOpenfp1);

%Plot of FP1 Waves for Eyes Open
figure(6);
subplot(4,1,1);
plot(topen,alphaOpenfp1);
title("Alpha Wave Open FP1");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([0.3,0.9]);
subplot(4,1,2);
plot(topen,betaOpenfp1);
title("Beta Wave Open FP1");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([0.3,0.9]);
subplot(4,1,3);
plot(topen,deltaOpenfp1);
title("Delta Wave Open FP1");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([0.3,0.9]);
subplot(4,1,4);
plot(topen,thetaOpenfp1);
title("Theta Wave Open FP1");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([0.3,0.9]);

%Open FP2 Filtered
alphaOpenfp2 = filter(alpha,filteredOpenfp2);
betaOpenfp2 = filter(beta,filteredOpenfp2);
deltaOpenfp2 = filter(delta,filteredOpenfp2);
thetaOpenfp2 = filter(theta,filteredOpenfp2);

%Plot of FP2 Waves for Eyes Open
figure(7);
subplot(4,1,1);
plot(topen,alphaOpenfp2);
title("Alpha Wave Open FP2");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([0.3,0.9]);
subplot(4,1,2);
plot(topen,betaOpenfp2);
title("Beta Wave Open FP2");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([0.3,0.9]);
subplot(4,1,3);
plot(topen,deltaOpenfp2);
title("Delta Wave Open FP2");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([0.3,0.9]);
subplot(4,1,4);
plot(topen,thetaOpenfp2);
title("Theta Wave Open FP2");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([0.3,0.9]);

%% Part 4) Eyes Closed
closedfp1 = dataClosed(:,2);
closedfp1 = closedfp1{:,:};
closedfp2 = dataClosed(:,3);
closedfp2 = closedfp2{:,:};
filteredClosedfp1 = filter(filt,closedfp1);
filteredClosedfp2 = filter(filt,closedfp2);

%Closed O1 Filtered
alphaClosedO1 = filter(alpha,filteredClosedO1);
betaClosedO1 = filter(beta,filteredClosedO1);
deltaClosedO1 = filter(delta,filteredClosedO1);
thetaClosedO1 = filter(theta,filteredClosedO1);

%Plot of O1 Waves for Eyes Closed
figure(8);
subplot(4,1,1);
plot(tclosed,alphaClosedO1);
title("Alpha Wave Closed O1");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);
subplot(4,1,2);
plot(tclosed,betaClosedO1);
title("Beta Wave Closed O1");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);
subplot(4,1,3);
plot(tclosed,deltaClosedO1);
title("Delta Wave Closed O1");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);
subplot(4,1,4);
plot(tclosed,thetaClosedO1);
title("Theta Wave Open O1");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);

%Closed O2 Filtered
alphaClosedO2 = filter(alpha,filteredClosedO2);
betaClosedO2 = filter(beta,filteredClosedO2);
deltaClosedO2 = filter(delta,filteredClosedO2);
thetaClosedO2 = filter(theta,filteredClosedO2);

%Plot of O2 Waves for Eyes Closed
figure(9);
subplot(4,1,1);
plot(tclosed,alphaClosedO2);
title("Alpha Wave Closed O2");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);
subplot(4,1,2);
plot(tclosed,betaClosedO2);
title("Beta Wave Closed O2");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);
subplot(4,1,3);
plot(tclosed,deltaClosedO2);
title("Delta Wave Closed O2");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);
subplot(4,1,4);
plot(tclosed,thetaClosedO2);
title("Theta Wave Open O2");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);

%Closed FP1 Filtered
alphaClosedfp1 = filter(alpha,filteredClosedfp1);
betaClosedfp1 = filter(beta,filteredClosedfp1);
deltaClosedfp1 = filter(delta,filteredClosedfp1);
thetaClosedfp1 = filter(theta,filteredClosedfp1);

%Plot of FP1 Waves for Eyes Closed
figure(10);
subplot(4,1,1);
plot(tclosed,alphaClosedfp1);
title("Alpha Wave Closed FP1");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);
subplot(4,1,2);
plot(tclosed,betaClosedfp1);
title("Beta Wave Closed FP1");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);
subplot(4,1,3);
plot(tclosed,deltaClosedfp1);
title("Delta Wave Closed FP1");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);
subplot(4,1,4);
plot(tclosed,thetaClosedfp1);
title("Theta Wave Open FP1");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);

%Closed FP2 Filtered
alphaClosedfp2 = filter(alpha,filteredClosedfp2);
betaClosedfp2 = filter(beta,filteredClosedfp2);
deltaClosedfp2 = filter(delta,filteredClosedfp2);
thetaClosedfp2 = filter(theta,filteredClosedfp2);

%Plot of FP2 Waves for Eyes Closed
figure(11);
subplot(4,1,1);
plot(tclosed,alphaClosedfp2);
title("Alpha Wave Closed FP2");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);
subplot(4,1,2);
plot(tclosed,betaClosedfp2);
title("Beta Wave Closed FP2");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);
subplot(4,1,3);
plot(tclosed,deltaClosedfp2);
title("Delta Wave Closed FP2");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);
subplot(4,1,4);
plot(tclosed,thetaClosedfp2);
title("Theta Wave Open FP2");
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);

%% Part 5) EEG Blinks
dataBlinks = readtable("EEGblinks.csv");
%EEG Blinks
blinksO1 = dataBlinks(:,4);
blinksO1 = blinksO1{:,:};
blinksO2 = dataBlinks(:,5);
blinksO2 = blinksO2{:,:};
tblinks = dataBlinks(:,1);
tblinks = dataBlinks(:,:);
tblinks = (0:length(blinksO1)-1);
tblinks = tblinks*0.002;
filteredBlinksO1 = filter(filt,blinksO1);
filteredBlinksO2 = filter(filt,blinksO2);
figure(12);
subplot(4,1,1);
plot(tblinks,blinksO1);
title("Unfiltered Blinks O1");
xlabel("Time (s)");
ylabel("Voltage (uV)");
xlim([30,90]);
subplot(4,1,2);
plot(tblinks,blinksO2);
title("Unfiltered Blinks O2");
xlabel("Time (s)");
ylabel("Voltage (uV)");
xlim([30,90]);
subplot(4,1,3);
plot(tblinks,filteredBlinksO1);
title("Filtered Blinks O1");
xlabel("Time (s)");
ylabel("Voltage (uV)");
xlim([30,90]);
subplot(4,1,4);
plot(tblinks,filteredBlinksO2);
title("Filtered Blinks O2");
xlabel("Time (s)");
ylabel("Voltage (uV)");
xlim([30,90]);

%% EEG Chew
dataChew = readtable("EEGchew.csv");
chewfp1 = dataChew(:,2);
chewfp1 = chewfp1{:,:};
chewfp2 = dataChew(:,3);
chewfp2 = chewfp2{:,:};
tchew = dataChew(:,1);
tchew = dataChew(:,:);
tchew = (0:length(chewfp1)-1);
tchew = tchew*0.002;
filteredChewfp1 = filter(filt,chewfp1);
filteredChewfp2 = filter(filt,chewfp2);
figure(13)
subplot(4,1,1)
plot(tchew,chewfp1)
title("Unfiltered FP1 Chew")
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,60])
subplot(4,1,2)
plot(tchew,chewfp2)
title("Unfiltered FP2 Chew")
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,60])
subplot(4,1,3)
plot(tchew,filteredChewfp1)
title("Filtered FP1 Chew")
xlabel("Time(s)")
ylabel("Voltage(uV)")
subplot(4,1,4)
plot(tchew,filteredChewfp2)
title("Filtered FP2 Chew")
xlabel("Time(s)")
ylabel("Voltage(uV)")

%% Part 5) EEG Motion
dataMotion = readtable("EEGmotion.csv");
motionO1 = dataMotion(:,5);
motionO1 = motionO1{:,:};
motionO2 = dataMotion(:,4);
motionO2 = motionO2{:,:};
motionfp1 = dataMotion(:,2);
motionfp1 = motionfp1{:,:};
motionfp2 = dataMotion(:,3);
motionfp2 = motionfp2{:,:};
tmotion = dataMotion(:,1);
tmotion = dataMotion(:,:);
tmotion = (0:length(motionO1)-1);
tmotion = tmotion*0.002;
filteredMotionO1 = filter(filt,motionO1);
filteredMotionO2 = filter(filt,motionO2);
filteredMotionfp1 = filter(filt,motionfp1);
filteredMotionfp2 = filter(filt,motionfp2);
figure(14)
subplot(4,2,1)
plot(tmotion,motionO1)
title("Unfiltered O1 Motion")
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);
subplot(4,2,2)
plot(tmotion,filteredMotionO1)
title("Filtered O1 Motion")
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);
subplot(4,2,3)
plot(tmotion,motionO2)
title("Unfiltered O2 Motion")
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);
subplot(4,2,4)
plot(tmotion,filteredMotionO2)
title("Filtered O2 Motion")
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);
subplot(4,2,5)
plot(tmotion,motionfp1)
title("Unfiltered FP1 Motion")
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);
subplot(4,2,6)
plot(tmotion,filteredMotionfp1)
title("Filtered FP1 Motion")
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);
subplot(4,2,7)
plot(tmotion,motionfp2)
title("Unfiltered FP2 Motion")
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);
subplot(4,2,8)
plot(tmotion,filteredMotionfp2)
title("Filtered FP2 Motion")
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);

%% Part 5) b)
bandstopFilt = designfilt('bandstopiir','FilterOrder',8, ...
'PassbandFrequency1',0.5,'PassbandFrequency2',22, ...
'SampleRate',500);
fvtool(bandstopFilt,Analysis="freq");
dataBlinks = readtable("EEGblinks.csv");
blinksO1 = dataBlinks(:,4);
blinksO1 = blinksO1{:,:};
blinksO2 = dataBlinks(:,5);
blinksO2 = blinksO2{:,:};
tblinks = dataBlinks(:,1);
tblinks = dataBlinks(:,:);
tblinks = (0:length(blinksO1)-1);
tblinks = tblinks*0.002;
noiseBlinksO1 = filter(bandstopFilt,blinksO1);
noiseBlinksO2 = filter(bandstopFilt,blinksO2);
figure(15);
subplot(2,1,1);
plot(tblinks,noiseBlinksO1);
title("Extracted Noise of Blinks O1")
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);
subplot(2,1,2);
plot(tblinks,noiseBlinksO2);
title("Extracted Noise of Blinks O2")
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);
dataChew = readtable("EEGchew.csv");
chewfp1 = dataChew(:,2);
chewfp1 = chewfp1{:,:};
chewfp2 = dataChew(:,3);
chewfp2 = chewfp2{:,:};
tchew = dataChew(:,1);
tchew = dataChew(:,:);
tchew = (0:length(chewfp1)-1);
tchew = tchew*0.002;
noiseChewfp1 = filter(bandstopFilt,chewfp1);
noiseChewfp2 = filter(bandstopFilt,chewfp2);
figure(16)
subplot(2,1,1);
plot(tchew,noiseChewfp1);
title("Extracted Noise of Chew FP1")
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([0.2,0.4])
subplot(2,1,2);
plot(tchew,noiseChewfp2);
title("Extracted Noise of Chew FP2")
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([0.2,0.4])
dataMotion = readtable("EEGmotion.csv");
motionO1 = dataMotion(:,5);
motionO1 = motionO1{:,:};
motionO2 = dataMotion(:,4);
motionO2 = motionO2{:,:};
motionfp1 = dataMotion(:,2);
motionfp1 = motionfp1{:,:};
motionfp2 = dataMotion(:,3);
motionfp2 = motionfp2{:,:};
tmotion = dataMotion(:,1);
tmotion = dataMotion(:,:);
tmotion = (0:length(motionO1)-1);
tmotion = tmotion*0.002;
noiseMotionO1 = filter(bandstopFilt,motionO1);
noiseMotionO2 = filter(bandstopFilt,motionO2);
noiseMotionfp1 = filter(bandstopFilt,motionfp1);
noiseMotionfp2 = filter(bandstopFilt,motionfp2);
figure(17)
subplot(4,1,1);
plot(tmotion,noiseMotionO1);
title("Extracted Noise of Motion O1")
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);
subplot(4,1,2);
plot(tmotion,noiseMotionO2);
title("Extracted Noise of Motion O2")
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);
subplot(4,1,3);
plot(tmotion,noiseMotionfp1);
title("Extracted Noise of Motion FP1")
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);
subplot(4,1,4);
plot(tmotion,noiseMotionfp2);
title("Extracted Noise of Motion FP2")
xlabel("Time(s)")
ylabel("Voltage(uV)")
xlim([30,90]);