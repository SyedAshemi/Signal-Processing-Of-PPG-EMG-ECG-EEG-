function output = SyncAvg(input, M)
    pulses = cell(M, 1);
    rand_indices = randi(length(input), M, 1);
    for i = 1:M
        pulses{i} = input{rand_indices(i)};
    end

    pulse_lengths = cellfun(@length, pulses);
    if ~all(pulse_lengths == pulse_lengths(1))
        error('All pulses must have the same length.');
    end
    
    temp = zeros(pulse_lengths(1), 1);
    for i = 1:length(pulses{1})
        for k = 1:M
            temp(i) = temp(i) + pulses{k}(i);
        end
    end
    output = temp ./ M;
end
