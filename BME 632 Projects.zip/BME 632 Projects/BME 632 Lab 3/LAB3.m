%% PART B
% EXERCISE 1 - NORMAL RESTING ECG
filename = 'sitECG.csv';
freq = 1000; % sampling frequency in Hz
sitECGdata = readtable(filename, 'PreserveVariableNames', true);
sitECGdata = removevars(sitECGdata, 'BioRadio Event');
time = 0:(1/freq):((size(sitECGdata)-1)/freq);
time = time.';
sitECGdata.("Elapsed Time") = time;

% Remove sitECG noise
sitECG = sitECGdata(sitECGdata.("Elapsed Time")>=5,:);
sitECG = sitECG(sitECG.("Elapsed Time")<=25.1,:);
time = 0:(1/freq):((size(sitECG)-1)/freq);
time = time.';
sitECG.("Elapsed Time") = time;

% Plot of all channels
subplot(3,1,1)
plot(sitECG.("Elapsed Time"), sitECG.Lead1);
title('Lead 1');
subplot(3,1,2)
plot(sitECG.("Elapsed Time"), sitECG.Lead2);
title('Lead 2');
subplot(3,1,3)
plot(sitECG.("Elapsed Time"), sitECG.Lead3);
title('Lead 3');

%% EXERCISE 1.1
% Cut out 4 beats 
sitECG2 = sitECG(sitECG.("Elapsed Time")>=0.35,:);
sitECG2 = sitECG2(sitECG2.("Elapsed Time")<=5,:);
time = 0:(1/freq):((size(sitECG2)-1)/freq);
time = time.';
sitECG2.("Elapsed Time") = time;

% Plot of 4 beats
plot(sitECG2.("Elapsed Time"), sitECG2.Lead1);
title('4 beats of Lead 1');
ylabel('Amplitude (mV)');
xlabel('Time (s)'); xlim tight;
grid on;

%% PQRST FEATURES
for i = 1:4
    gtext('P');
    gtext('Q');
    gtext('R');
    gtext('S');
    gtext('T');
end

%% AVERAGE HEART
lead1 = sitECG2.Lead1;
[pks, loc] = findpeaks(lead1, 1000, "MinPeakHeight", 0.3);

HR = zeros(length(loc)-1,1);
for i = 2:length(loc)
    HR(i-1) = (1/(loc(i)-loc(i-1)))*(60);
end
avgHR = mean(HR);
disp("Average Heart is: " + avgHR);

%% EXERCISE 1.2
lead1 = sitECG.Lead1;
lead2 = sitECG.Lead2;
lead3 = sitECG.Lead3;

[lead2_est, abs_diff, lead2_mse] = EX12(lead1, lead2, lead3);

% Plot of estimated lead2 and measured (actual) lead2
subplot(2,1,1)
plot(sitECG.("Elapsed Time"), lead2_est, 'r', 'LineWidth', 2);
hold on
plot(sitECG.("Elapsed Time"), lead2, 'b', 'LineWidth', 1.5);
hold off
title('Estimated and Measured Potential of Lead 2');
ylabel('Amplitude (mV)');
xlabel('Time (s)');
legend('Estimated Potential', 'Measured Potential');
axis([0 5 -0.6 1.4]);
grid on;

% Plot absolute difference between estimated and measured lead2
subplot(2,1,2)
plot(sitECG.("Elapsed Time"), abs_diff);
title('Absolute Difference between Estimated and Measured Potential for Lead2');
ylabel('Residual');
xlabel('Time (s)');
axis([0 5 0 0.003]);
grid on;

% Report the MSE value
disp("MSE value is:" + lead2_mse);

%% EXERCISE 1.3 CALCULATION OF MAGNITUDE FOR SITECG
filename = 'sitECG.csv';
freq = 1000; 
sitECGdata = readtable(filename, 'PreserveVariableNames', true);
sitECGdata = removevars(sitECGdata, 'BioRadio Event');
time = 0:(1/freq):((size(sitECGdata)-1)/freq);
time = time.';
sitECGdata.("Elapsed Time") = time;

% Normalizing the data
sitECGdata.Lead1 = sitECGdata.Lead1 - mean(sitECGdata.Lead1);
sitECGdata.Lead1 = sitECGdata.Lead1 / std(sitECGdata.Lead1);

sitECGdata.Lead2 = sitECGdata.Lead2 - mean(sitECGdata.Lead2);
sitECGdata.Lead2 = sitECGdata.Lead2 / std(sitECGdata.Lead2);

% Calculate average magnitude of Lead 1 and Lead 2
avg_Lead1 = mean(abs(sitECGdata.Lead1));
avg_Lead2 = mean(abs(sitECGdata.Lead2));

% Display the magnitudes
disp(['Magnitude of SitECG Lead 1: ', num2str(avg_Lead1)]);
disp(['Magnitude of SitECG Lead 2: ', num2str(avg_Lead2)]);

%% EXERCISE 1.3 CALCULATION OF MAGNITUDE FOR LAYING ECG
filename = 'layingECG.csv';
freq = 1000; 
layingECGdata = readtable(filename, 'PreserveVariableNames', true);
layingECGdata = removevars(layingECGdata, 'BioRadio Event');
time = 0:(1/freq):((size(layingECGdata)-1)/freq);
time = time.';
layingECGdata.("Elapsed Time") = time;

% Normalizing the data
layingECGdata.Lead1 = layingECGdata.Lead1 - mean(layingECGdata.Lead1);
layingECGdata.Lead1 = layingECGdata.Lead1 / std(layingECGdata.Lead1);

layingECGdata.Lead2 = layingECGdata.Lead2 - mean(layingECGdata.Lead2);
layingECGdata.Lead2 = layingECGdata.Lead2 / std(layingECGdata.Lead2);

% Calculate average magnitude of Lead 1 and Lead 2
avg_Lead1 = mean(abs(layingECGdata.Lead1));
avg_Lead2 = mean(abs(layingECGdata.Lead2));

% Display the magnitudes
disp(['Magnitude of LayingECG Lead 1: ', num2str(avg_Lead1)]);
disp(['Magnitude of LayingECG Lead 2: ', num2str(avg_Lead2)]);

%% EXERCISE 1.4
window = sitECG(sitECG.("Elapsed Time")<=6.5,:);
window = window(window.("Elapsed Time")>=0.5,:);
t1 = 0:(1/freq):((size(window)-1)/freq);
lead1 = window.Lead1;

temp = sitECG(sitECG.("Elapsed Time")>=2.2,:);
temp = temp(temp.("Elapsed Time")<=2.86,:);

% Cross correlate template and lead1
template = temp.Lead1;
subplot(3,1,1) % Plot of template
plot(temp.("Elapsed Time"), template);
title('Template');
ylabel('Amplitude (mV)');
xlabel('Time (s)'); xlim tight;
grid on;
subplot(3,1,2) % Plot of lead 1 signal
plot(t1, lead1);
title('Lead 1');
ylabel('Amplitude (mV)');
xlabel('Time (s)'); xlim tight;
grid on;

% Cross correlation between template and lead 1
r = xcorr(template, lead1);
% Normalize correlation
rN = (r-min(r))./(max(r)-min(r));
t2 = 0:(1/freq):((length(rN)-1)/freq);
subplot(3,1,3) % Plot of correlation
plot(t2, rN);
title('Correlation between Template and Lead 1');
ylabel('Amplitude');
xlabel('Time (s)');
xlim([0 6.5]);
grid on;

% Automatically compute HR  using r
[pks, loc] = findpeaks(rN, 1000, "MinPeakHeight", 0.8);
HR = ((1/mean(diff(loc)))*60);

% Average HR
avgHR = mean(HR);
disp("Average Heart is: " + avgHR);

%% EXERCISE 1.5
filename = 'subjectECG1.csv';
freq = 1000;
sub1data = readtable(filename, 'PreserveVariableNames', true);
sub1data = removevars(sub1data, 'BioRadio Event');
time = 0:(1/freq):((size(sub1data)-1)/freq);
time = time.';
sub1data.("Elapsed Time") = time;
% Remove noise
sub1data = sub1data(sub1data.("Elapsed Time")>=5,:);
sub1data = sub1data(sub1data.("Elapsed Time")<=16,:);
time = 0:(1/freq):((size(sub1data)-1)/freq);
time = time.';
sub1data.("Elapsed Time") = time;

% View full data
subplot(3,1,1)
plot(sub1data.("Elapsed Time"), sub1data.Lead1);
title('Lead 1');
subplot(3,1,2)
plot(sub1data.("Elapsed Time"), sub1data.Lead2);
title('Lead 2');
subplot(3,1,3)
plot(sub1data.("Elapsed Time"), sub1data.Lead3);
title('Lead 3');

sub1_lead1 = sub1data.Lead1;

disp(length(sub1_lead1));

%% MANUAL TRIGGER
[pks1, locs1] = findpeaks(sub1_lead1, 1000, 'MinPeakHeight', 0.3);
idx1 = round(locs1 .* freq);
tp1 = mean(diff(locs1));
np1 = length(pks1);
man_pulses = cell(np1, 1);

% Check the size of sub1_lead1
disp(['Size of sub1_lead1: ', num2str(length(sub1_lead1))]);

% isolate pulses
for i = 1:length(locs1)
    lower_bound = idx1(i) - 300;
    upper_bound = idx1(i) + 500;
    disp(['Lower bound: ', num2str(lower_bound), ', Upper bound: ', num2str(upper_bound)]);
    
    % Ensure bounds are within range and non-negative
    if lower_bound > 0 && upper_bound <= length(sub1_lead1)
        man_pulses{i} = sub1_lead1(lower_bound:upper_bound);
    else
        disp('Bounds are out of range or negative!');
    end
end

figure(1)
subplot(2,1,1)
plot(time, sub1_lead1);
hold on
plot(time(idx1), sub1_lead1(idx1), '*r');
hold off
title('Lead 1 ECG');
legend('ECG', 'Trigger Point');
ylabel('Amplitude (mV)');
xlabel('Time'); xlim tight;
grid on;

% Plot each pulse individually
subplot(2,1,2)
hold on
for i = 1:np1
    t = 0:(1/freq):((length(man_pulses{i}) - 1) / freq);
    plot(t, man_pulses{i});
end
hold off
title('Plot of all pulses');
ylabel('Amplitude (mV)');
xlabel('Time (s)');
grid on;

%% SYNCRONIZED AVG FOR M = 5, 10, 30
M = [5, 10, 30];
figure(2)
for i = 1:length(M)
    % Create synchronized pulses
    synchronized_pulses = cell(size(man_pulses));
    max_length = max(cellfun(@length, man_pulses));
    for j = 1:length(man_pulses)
        current_pulse = man_pulses{j};
        if length(current_pulse) < max_length
            current_pulse = [current_pulse; zeros(max_length - length(current_pulse), 1)];
        end
        synchronized_pulses{j} = current_pulse;
    end
    
    % Calculate synchronized average
    output = SyncAvg(synchronized_pulses, M(i));
    
    % Plot
    t2 = 0:(1/freq):((length(output)-1)/freq);
    t2 = t2.';
    subplot(3,1,i)
    plot(t2, output);
    title(['M = ', num2str(M(i))]);
    ylabel('Amplitude (mV)');
    xlabel('Time (s)');
    grid on;
    hold on
    ylim([-0.5, 0.5]);
end
hold off

%% AUTOMATIC TRIGGER
template_start = idx1(1) - 300;
template_end = idx1(1) + 500;

% Check if indices are within bounds
if template_start < 1
    template_start = 1;
end
if template_end > 10285
    template_end = 10285;
end

template = sub1_lead1(template_start:template_end);
t3 = 0:(1/freq):((length(template)-1)/freq);

figure(1)
subplot(3,1,1)
plot(t3, template);
title('Template');
ylabel('Amplitude (mV)');
xlabel('Time (s)'); xlim tight;
grid on;
subplot(3,1,2)
t4 = 0:(1/freq):((length(sub1_lead1)-1)/freq);
plot(t4, sub1_lead1);
title('Lead 1');
ylabel('Amplitude (mV)');
xlabel('Time (s)'); xlim tight;
grid on;

% cross correlation between template and lead 1
r2 = xcorr(template, sub1_lead1);

% normalize correlation
rN2 = (r2-min(r2))./(max(r2)-min(r2));

% Adjusted indices for rN2
rN2_start = 638;
rN2_end = 11638;

rN2 = rN2(rN2_start:rN2_end);
t5 = 0:(1/freq):((length(rN2)-1)/freq);
subplot(313)
plot(t5, rN2);
title('Correlation between Template and Lead 1');
ylabel('Amplitude');
xlabel('Time (s)'); xlim tight;
grid on;

%% 
[pks2, loc2] = findpeaks(rN2, 1000, "MinPeakHeight", 0.3);
avgPulseTime = mean(diff(loc2));

aut_pulses = cell(length(loc2), 1);
idx1 = round(loc2.*freq);

for i = 1:length(loc2)
    pulse = sub1_lead1(idx1(i)-300:idx1(i)+500);
    aut_pulses{i} = pulse;
end

figure(2)
subplot(2,1,1)
plot(t4, sub1_lead1);
hold on
plot(t4(idx1), sub1_lead1(idx1), '*r');
hold off
title('Lead 1 ECG');
legend('ECG', 'Trigger Point');
ylabel('Amplitude');
xlabel('Time'); xlim tight;
grid on;

subplot(2,1,2)
hold on
all_pulses = [];  
all_times = [];   
for i = 1:length(aut_pulses)
    t = 0:(1/freq):((length(aut_pulses{i})-1)/freq);
    plot(t, aut_pulses{i});
    all_pulses = [all_pulses; aut_pulses{i}(:)]; 
    all_times = [all_times; t(:)];               
end
hold off
title('Plot of all pulses');
ylabel('Amplitude (mV)');
xlabel('Time (s)');
grid on;

ylim([min(all_pulses), max(all_pulses)]);

%% SYNCRONIZED AVG FOR M = 5, 10, 30, 50, 100
M = [5, 10, 30, 50, 100];
figure(3)

for i = 1:length(M)
    output = SyncAvg(aut_pulses, M(i));
    t2 = 0:(1/freq):((length(output)-1)/freq);
    t2 = t2.';
    subplot(length(M),1,i)
    plot(t2, output);
    title(['M = ', num2str(M(i))]);
    ylabel('Amplitude (mV)');
    xlabel('Time (s)');
    grid on;
    hold on
end
hold off

%% EXERCISE 2: MOTION ARTIFACTS
% Exercise 2.1
% --------------------------------------------------------------------------------
filename = 'artifactleftECG.csv';
left_data = readtable(filename,'PreserveVariableNames',true);
left_data = removevars(left_data,'BioRadio Event');
freq = 1000;
time = 0:(1/freq):((size(left_data)-1)/freq);
time = time.';
left_data.('Elapsed Time') = time;

figure(1)
plot(left_data.('Elapsed Time'),left_data.Lead1);
grid on;
xlabel('Time (s)');
ylabel('Potential (mV)');
title('Left Atrifact Lead 1 Potential');
xlim([3 7]);
ylim([-1 1]);

figure(2)
plot(left_data.('Elapsed Time'),left_data.Lead2);
grid on;
xlabel('Time (s)');
ylabel('Potential (mV)');
title('Left Artifact Lead 2 Potential');
xlim([3 7]);
ylim([-1 1.5]);

figure(3)
plot(left_data.('Elapsed Time'),left_data.Lead3);
grid on;
xlabel('Time (s)');
ylabel('Potential (mV)');
title('Left Artifact Lead 3 Potential');
xlim([3 7]);
ylim([-2 2]);

filename = 'artifactrightECG.csv';
right_data = readtable(filename,'PreserveVariableNames',true);
right_data = removevars(right_data,'BioRadio Event');
freq = 1000;
time = 0:(1/freq):((size(right_data)-1)/freq);
time = time.';
right_data.('Elapsed Time') = time;

figure(4)
plot(right_data.('Elapsed Time'),right_data.Lead1);
grid on;
xlabel('Time (s)');
ylabel('Potential (mV)');
title('Right Artifact Lead 1 Potential');
xlim([6 10]);
ylim([-2 2]);

figure(5)
plot(right_data.('Elapsed Time'),right_data.Lead2);
grid on;
xlabel('Time (s)');
ylabel('Potential (mV)');
title('Right Artifact Lead 2 Potential');
xlim([6 10]);

figure(6)
plot(right_data.('Elapsed Time'),right_data.Lead3);
grid on;
xlabel('Time (s)');
ylabel('Potential (mV)');
title('Right Artifact Lead 3 Potential');
xlim([6 10]);
ylim([-1 1]);

d = Einth(left_data,3,2);
e = einthoven(right_data,2,4);

figure(7)
plot(left_data.('Elapsed Time'),left_data.Lead1,'b');
hold on
plot(left_data.('Elapsed Time'),d,'r');
grid on;
xlabel('Time (s)');
ylabel('Potential (mV)');
title("Left Artifact Actual Lead 3 Signal and Einthoven's Law Estimate");
legend('Actual Signal','Estimated Signal');
ylim([-2 2]);
xlim([4 12]);

figure(8)
plot(right_data.('Elapsed Time'),right_data.Lead1,'b');
hold on
plot(right_data.('Elapsed Time'),e,'r');
grid on;
xlabel('Time (s)');
ylabel('Potential (mV)');
title("Right Artifact Actual Lead 2 Signal and Einthoven's Law Estimate");
legend('Actual Signal','Estimated Signal');
ylim([-2 3]);
xlim([4 12]);

%% PART C
% EXERCISE 1.1
sitData = readtable('sitECG.csv');
sit1 = sitData(:,2);
sit1 = sit1{:,:};
sit1 = (sit1.');
sit2 = sitData(:,3);
sit2 = sit2{:,:};
sit2 = (sit2.')*-1;
sit3 = sitData(:,4);
sit3 = sit3{:,:};
sit3 = (sit3.')*-1;
time1 = sitData(:,1);
time1 = time1{:,:};
time1 = (0:length(time1)-1);
time1 = time1*0.001;
mag1 = fft(sit1);
mag2 = fft(sit2);
mag3 = fft(sit3);
a1 = abs(mag1/length(time1));
a2 = a1(1:length(time1)/2+1);
a2(2:end-1) = 2*a2(2:end-1);
freq1 = 1000*(0:(length(time1)-1))/length(time1);
b1 = abs(mag2/length(time1));
b2 = b1(1:length(time1)/2+1);
b2(2:end-1) = 2*b2(2:end-1);
freq2 = 1000*(0:(length(time1)-1))/length(time1);
c1 = abs(mag3/length(time1));
c2 = c1(1:length(time1)/2+1);
c2(2:end-1) = 2*c2(2:end-1);
freq3 = 1000*(0:(length(time1)-1))/length(time1);

figure(1);
subplot(3,1,1);
plot(time1, sit1);
xlim([5 9])
xlabel("Time(s)");
ylabel("Voltage(mV)");
title("Lead 1 vs Time");
subplot(3,1,2);
plot(time1, sit2);
xlim([5 9])
xlabel("Time(s)");
ylabel("Voltage(mV)");
title("Lead 2 vs Time");
subplot(3,1,3);
plot(time1, sit3);
xlim([5 9])
xlabel("Time(s)");
ylabel("Voltage(mV)");
title("Lead 3 vs Time");

%%
figure(2);
subplot(3,1,1);
plot(freq1,mag1);
xlabel("Frequency(Hz)");
ylabel("Magnitude Spectrum(dB)");
xlim([0 25]);
title("Frequency and Magnitude Spectrum of Lead 1");
subplot(3,1,2);
plot(freq2,mag2);
xlabel("Frequency(Hz)");
ylabel("Magnitude Spectrum(dB)");
xlim([0 25]);
title("Frequency and Magnitude Spectrum of Lead 2");
subplot(3,1,3);
plot(freq3,mag3);
xlabel("Frequency(Hz)");
xlim([0 25]);
ylabel("Magnitude Spectrum(dB)")
title("Frequency and Magnitude Spectrum of Lead 3");

%% EXERCISE 1.2 PART B
% Lead 1
sitData = readtable('sitECG.csv');
sit1 = sitData(:,2);
sit1 = sit1{:,:};
sit2 = sitData(:,3);
sit2 = sit2{:,:};
sit3 = sitData(:,4);
sit3 = sit3{:,:};
time = isoData(:,1);

time = time{:,:};
time = (0:length(time)-1);
time = time*0.001;
[b,a] = sos2tf(SOS,G);
[b1,a1] = sos2tf(SOS4,G4);
butter4l1 = filter(b,a,sit1);
cheb4l1 = filter(b1,a1,sit1);
butter4l2 = filter(b,a,sit2);
cheb4l2 = filter(b1,a1,sit2);
butter4l3 = filter(b,a,sit3);
cheb4l3 = filter(b1,a1,sit3);
figure(1);
subplot(3,1,1)
plot(time, sit1);
xlim([5 9]);
xlabel("Time(s)");
ylabel("Voltage (mV)");
title("Lead 1");
subplot(3,1,2);
plot(time, butter4l1);
xlim([5 9]);
xlabel("Time(s)");
ylabel("Voltage (mV)");
title("Lead 1 Filtered Through Butterworth Order 4");
subplot(3,1,3);
plot(time, cheb4l1);
xlim([5 9]);
xlabel("Time(s)");
ylabel("Voltage (mV)");
title("Lead 1 Filtered Through Chebyshev Type I Order 4");

%% Lead 2 
figure(2);
subplot(3,1,1)
plot(time, sit2);
xlim([5 9]);
xlabel("Time(s)");
ylabel("Voltage (mV)");
title("Lead 2");
subplot(3,1,2);
plot(time, butter4l2);
xlim([5 9]);
xlabel("Time(s)");
ylabel("Voltage (mV)");
title("Lead 2 Filtered Through Butterworth Order 4");
subplot(3,1,3);
plot(time, cheb4l2);
xlim([5 9]);
xlabel("Time(s)");
ylabel("Voltage (mV)");
title("Lead 2 Filtered Through Chebyshev Type I Order 4");

%% Lead 3
figure(3);
subplot(3,1,1)
plot(time, sit3);
xlim([5 9]);
xlabel("Time(s)");
ylabel("Voltage (mV)");
title("Lead 3");
subplot(3,1,2);
plot(time, butter4l3);
xlim([5 9]);
xlabel("Time(s)");
ylabel("Voltage (mV)");
title("Lead 3 Filtered Through Butterworth Order 4");
subplot(3,1,3);
plot(time, cheb4l3);
xlim([5 9]);
xlabel("Time(s)");
ylabel("Voltage (mV)");
title("Lead 3 Filtered Through Chebyshev Type I Order 4");

%% EXERCISE 1.2 PART C
% For Lead 1 Butterworth order 4, 8, 20, 50
[b4,a4] = sos2tf(SOS,G);
[b8,a8] = sos2tf(SOS1,G1);
[b20,a20] = sos2tf(SOS2,G2);
[b50,a50] = sos2tf(SOS3,G3);
butter4l1 = filter(b4,a4,sit1);
butter4l2 = filter(b4,a4,sit2);
butter4l3 = filter(b4,a4,sit3);
butter8l1 = filter(b8,a8,sit1);
butter8l2 = filter(b8,a8,sit2);
butter8l3 = filter(b8,a8,sit3);
butter20l1 = filter(b20,a20,sit1);
butter20l2 = filter(b20,a20,sit2);
butter20l3 = filter(b20,a20,sit3);
butter50l1 = filter(b50,a50,sit1);
butter50l2 = filter(b50,a50,sit2);
butter50l3 = filter(b50,a50,sit3);
figure(1);
subplot(5,1,1)
plot(time, sit1);
xlim([5 9]);
xlabel("Time(s)");
ylabel("Voltage (mV)");
title("Lead 1");
subplot(5,1,2);
plot(time, butter4l1);
xlim([5 9]);
xlabel("Time(s)");
ylabel("Voltage (mV)");
title("Lead 1 Filtered Through Butterworth Order 4");
subplot(5,1,3);
plot(time, butter8l1);
xlim([5 9]);
xlabel("Time(s)");
ylabel("Voltage (mV)");
title("Lead 1 Filtered Through Butterworth Order 8");
subplot(5,1,4);
plot(time, butter20l1);
xlim([5 9]);
xlabel("Time(s)");
ylabel("Voltage (mV)");
title("Lead 1 Filtered Through Butterworth Order 20");
subplot(5,1,5);
plot(time, butter50l1);
xlim([5 9]);
xlabel("Time(s)");
ylabel("Voltage (mV)");
title("Lead 1 Filtered Through Butterworth Order 50");

%% For Lead 2 Butterworth order 4, 8, 20, 50
figure(2);
subplot(5,1,1)
plot(time, sit2);
xlim([5 9]);
xlabel("Time(s)");
ylabel("Voltage (mV)");
title("Lead 2");
subplot(5,1,2);
plot(time, butter4l2);
xlim([5 9]);
xlabel("Time(s)");
ylabel("Voltage (mV)");
title("Lead 2 Filtered Through Butterworth Order 4");
subplot(5,1,3);
plot(time, butter8l2);
xlim([5 9]);
xlabel("Time(s)");
ylabel("Voltage (mV)");
title("Lead 2 Filtered Through Butterworth Order 8");
subplot(5,1,4);
plot(time, butter20l2);
xlim([5 9]);
xlabel("Time(s)");
ylabel("Voltage (mV)");
title("Lead 2 Filtered Through Butterworth Order 20");
subplot(5,1,5);
plot(time, butter50l2);
xlim([5 9]);
xlabel("Time(s)");
ylabel("Voltage (mV)");
title("Lead 2 Filtered Through Butterworth Order 50");

%% For Lead 3 Butterworth order 4, 8, 20, 50
figure(3);
subplot(5,1,1)
plot(time, sit2);
xlim([5 9]);
xlabel("Time(s)");
ylabel("Voltage (mV)");
title("Lead 3");
subplot(5,1,2);
plot(time, butter4l3);
xlim([5 9]);
xlabel("Time(s)");
ylabel("Voltage (mV)");
title("Lead 3 Filtered Through Butterworth Order 4");
subplot(5,1,3);
plot(time, butter8l3);
xlim([5 9]);
xlabel("Time(s)");
ylabel("Voltage (mV)");
title("Lead 3 Filtered Through Butterworth Order 8");
subplot(5,1,4);
plot(time, butter20l3);
xlim([5 9]);
xlabel("Time(s)");
ylabel("Voltage (mV)");
title("Lead 3 Filtered Through Butterworth Order 20");
subplot(5,1,5);
plot(time, butter50l3);
xlim([5 9]);
xlabel("Time(s)");
ylabel("Voltage (mV)");
title("Lead 3 Filtered Through Butterworth Order 50");

%% EXERCISE 1.2 PART D
% Frequency spectrum for lead 1
mag_butter4l1 = abs(fft(butter4l1));
mag_butter8l1 = abs(fft(butter8l1));
mag_butter20l1 = abs(fft(butter20l1));
mag_butter50l1 = abs(fft(butter50l1));

mag_butter4l2 = abs(fft(butter4l2));
mag_butter8l2 = abs(fft(butter8l2));
mag_butter20l2 = abs(fft(butter20l2));
mag_butter50l2 = abs(fft(butter50l2));

mag_butter4l3 = abs(fft(butter4l3));
mag_butter8l3 = abs(fft(butter8l3));
mag_butter20l3 = abs(fft(butter20l3));
mag_butter50l3 = abs(fft(butter50l3));

fs = 1000;
freq = (0:length(butter4l1)-1) / length(butter4l1) * fs; 

figure(1);
subplot(4,1,1);
plot(freq, mag_butter4l1);
xlim([0 25]);
xlabel("Frequency (Hz)");
ylabel("Magnitude Spectrum (dB)");
title("Frequency and Magnitude Spectrum of Lead 1 (Butterworth Order 4)");

subplot(4,1,2);
plot(freq, mag_butter8l1);
xlim([0 25]);
xlabel("Frequency (Hz)");
ylabel("Magnitude Spectrum (dB)");
title("Frequency and Magnitude Spectrum of Lead 1 (Butterworth Order 8)");

subplot(4,1,3);
plot(freq, mag_butter20l1);
xlim([0 25]);
xlabel("Frequency (Hz)");
ylabel("Magnitude Spectrum (dB)");
title("Frequency and Magnitude Spectrum of Lead 1 (Butterworth Order 20)");

subplot(4,1,4);
plot(freq, mag_butter20l1);
xlim([0 25]);
xlabel("Frequency (Hz)");
ylabel("Magnitude Spectrum (dB)");
title("Frequency and Magnitude Spectrum of Lead 1 (Butterworth Order 50)");

%% Frequency spectrum for lead 2
mag_butter4l2 = abs(fft(butter4l2));
mag_butter8l2 = abs(fft(butter8l2));
mag_butter20l2 = abs(fft(butter20l2));
mag_butter50l2 = abs(fft(butter50l2));
mag_butter4l3 = abs(fft(butter4l3));
mag_butter8l3 = abs(fft(butter8l3));
mag_butter20l3 = abs(fft(butter20l3));
mag_butter50l3 = abs(fft(butter50l3));

fs = 1000;
freq = (0:length(butter4l2)-1) / length(butter4l2) * fs; % Sampling frequency is 1000 Hz

figure(3);
subplot(4,1,1);
plot(freq, mag_butter4l2);
xlim([0 25]);
xlabel("Frequency (Hz)");
ylabel("Magnitude Spectrum (dB)");
title("Frequency and Magnitude Spectrum of Lead 2 (Butterworth Order 4)");

subplot(4,1,2);
plot(freq, mag_butter8l2);
xlim([0 25]);
xlabel("Frequency (Hz)");
ylabel("Magnitude Spectrum (dB)");
title("Frequency and Magnitude Spectrum of Lead 2 (Butterworth Order 8)");

subplot(4,1,3);
plot(freq, mag_butter20l2);
xlim([0 25]);
xlabel("Frequency (Hz)");
ylabel("Magnitude Spectrum (dB)");
title("Frequency and Magnitude Spectrum of Lead 2 (Butterworth Order 20)");

subplot(4,1,4);
plot(freq, mag_butter20l2);
xlim([0 25]);
xlabel("Frequency (Hz)");
ylabel("Magnitude Spectrum (dB)");
title("Frequency and Magnitude Spectrum of Lead 2 (Butterworth Order 50)");

%% Frequency spectrum for lead 3
figure(3);
subplot(4,1,1);
plot(freq, mag_butter4l3);
xlim([0 25]);
xlabel("Frequency (Hz)");
ylabel("Magnitude Spectrum (dB)");
title("Frequency and Magnitude Spectrum of Lead 3 (Butterworth Order 4)");

subplot(4,1,2);
plot(freq, mag_butter8l3);
xlim([0 25]);
xlabel("Frequency (Hz)");
ylabel("Magnitude Spectrum (dB)");
title("Frequency and Magnitude Spectrum of Lead 3 (Butterworth Order 8)");

subplot(4,1,3);
plot(freq, mag_butter20l3);
xlim([0 25]);
xlabel("Frequency (Hz)");
ylabel("Magnitude Spectrum (dB)");
title("Frequency and Magnitude Spectrum of Lead 3 (Butterworth Order 20)");

subplot(4,1,4);
plot(freq, mag_butter20l3);
xlim([0 25]);
xlabel("Frequency (Hz)");
ylabel("Magnitude Spectrum (dB)");
title("Frequency and Magnitude Spectrum of Lead 3 (Butterworth Order 50)");

%%
% Function Definitions
% --------------------------------------------------------------------------------
% Calculates lead 2 potential based on Einthoven's Law
function result = einthoven(table,column1,column2)
    col1 = table{:,column1};
    col2 = table{:,column2};
    result = col1 + col2;
end

% Calculates lead 1/3 potential based on Einthoven's Law
function result = Einth(table,column1,column2)
    col1 = table{:,column1};
    col2 = table{:,column2};
    result = col1 - col2;
end

% Calculates absolute difference between true and calculated
function diff = difference(data1,data2)
    trueV = data1{:,3};
    estimateV = data2(:,1);
    result = trueV - estimateV;
    diff = abs(result);
end

% Finds mean-squared error between true and estimated
function result = MSE(true,estimate)
    y = (true - estimate).^2;
    result = mean(y);
end