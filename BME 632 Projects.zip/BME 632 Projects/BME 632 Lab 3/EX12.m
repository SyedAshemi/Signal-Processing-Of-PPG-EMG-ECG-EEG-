function [output1, output2, output3] = EX12(input1, input2, input3)
    % input1 = lead1
    % input2 = lead2
    % input3 = lead3
    output1 = input1 + input3; % lead2 = lead1 + lead3
    output2 = abs(input2 - output1); % abs diff in estimated and actual lead2
    output3 = (rmse(output1, input2))^2; % means squared error for lead2
end
