% Experiment 1: Isometric muscle contraction
filename = 'IsoBiceps.csv';
data = readtable(filename, 'PreserveVariableNames', true);
data = removevars(data, 'BioRadio Event');
freq = 1000;
time = 0:(1/freq):((size(data)-1)/freq);
time = time.';
data.("Elapsed Time") = time;

plot(data.("Elapsed Time"), data.Bicep, 'b');

s1_1 = data(data.("Elapsed Time")>3, :);
s1_1 = s1_1(s1_1.("Elapsed Time")<8, :);
time1_1 = 0:(1/freq):((size(s1_1)-1)/freq);
time1_1 = time1_1.';
s1_1.("Elapsed Time") = time1_1;

% Window Size and its conversion
window = 1.0;
ws = freq*window;
sig = table2array(s1_1(:,2));
feat = STAnalysis(sig, ws);

% EMG signal and the STA features plot
% EMG signal
plot(s1_1.("Elapsed Time"), s1_1.Bicep, 'Color', "#FFC900");
hold on
% Mean
plot(s1_1.("Elapsed Time"), feat(:,1), 'r');
hold on
% Variance
plot(s1_1.("Elapsed Time"), feat(:,2), 'm');
hold on
% DR
plot(s1_1.("Elapsed Time"), feat(:,3), 'Color', "#717171");
hold on
% MS
plot(s1_1.("Elapsed Time"), feat(:,4), 'g');
hold on
% RMS
plot(s1_1.("Elapsed Time"), feat(:,5), 'b');
grid on;
title('STA @ window size of 1.0s');
xlabel('Time(s)');
ylabel('Excitation (mV)');
legend('EMG', 'Mean', 'Variance', 'DR', 'MS', 'RMS');
hold off

