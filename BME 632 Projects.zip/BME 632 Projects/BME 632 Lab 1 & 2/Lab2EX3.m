% Exp 3- Grasp Force Fatigue
filename = 'GraspFatigue.csv';
data = readtable(filename, 'PreserveVariableNames', true);
data = removevars(data, 'BioRadio Event');
freq = 1000;
time = 0:(1/freq):((size(data)-1)/freq);
time = time.';
data.("Elapsed Time") = time;

plot(data.("Elapsed Time"), data.Finger, 'b');

s1_1 = data(data.("Elapsed Time")>3, :);
s1_1 = s1_1(s1_1.("Elapsed Time")<8, :);
time1_1 = 0:(1/freq):((size(s1_1)-1)/freq);
time1_1 = time1_1.';
s1_1.("Elapsed Time") = time1_1;

% Window Size and its conversion
window = 1.0;
ws = freq*window;
sig = table2array(s1_1(:,2));
feat = STAnalysis(sig, ws);

% EMG signal and the STA features plot
% EMG signal
plot(s1_1.("Elapsed Time"), s1_1.Finger, 'Color', "#FFC900");
hold on
% Mean
plot(s1_1.("Elapsed Time"), feat(:,1), 'r');
grid on;
title('STA @ window size of 1.0s');
xlabel('Time(s)');
ylabel('Excitation (mV)');
legend('Finger EMG', 'Mean');
hold off

% Compute correlation with force signal
force_signal = s1_1.("Grip Strength Force"); % Assuming 'Force' is the name of the column containing force data
finger_mean_feature = feat(:, 1);
correlation_coefficient = corr(force_signal, finger_mean_feature);

disp(['Correlation coefficient between Finger EMG mean feature and Force signal: ', num2str(correlation_coefficient)]);

%% signal segmentation
points = linspace(6,120,20);
points = (points*freq)+1;
starts = [];
stops = [];
for i = 1:length(points)
    if mod(i,2) ~= 0
        starts = [starts, points(i)];
    end
    if mod(i,2) == 0
        stops = [stops, points(i)];
    end
end

%% 
segNo = length(starts);
% optimal window size
winSize = 1;
winSize = winSize*freq;

F = zeros(segNo,1);
M = zeros(segNo,1);

for i = 1:segNo
    forceSeg = force(starts(i):stops(i));
    mforce = mean(forceSeg);
    F(i) = mforce;

    emgSeg = EMG(starts(i):stops(i));
    feat = STAnalysis(emgSeg,winSize);
    mfeat = mean(feat);
    M(i) = mfeat(1);
end

%% Linear Regression 
fitMean = fitlm(F, M);
f = plot(fitMean);
f.set("LineWidth",1.5);
title('Mean VS. Force');
xlabel('Force (N)');
ylabel('Mean');
grid on;

