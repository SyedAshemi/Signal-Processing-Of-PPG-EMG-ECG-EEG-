%% Experiment 2- Grasp Force Measurement
filename = 'GraspForce.csv';
data = readtable(filename, 'PreserveVariableNames', true);
data = removevars(data, 'BioRadio Event');
freq = 1000;
time = 0:(1/freq):((size(data, 1)-1)/freq); 
time = time.';
data.("Elapsed Time") = time;

EMG = data.Finger;
force = data.("Grip Strength Force");

% Normalizing the force
normalForce = (force - min(force))./(max(force) - min(force));
normalForce(normalForce < 0.0) = 0; 

% Plot of EMG and Normalized Force
subplot(2,1,1)
plot(data.("Elapsed Time"), data.Finger);
title('EMG');
xlabel('Time(s)');
ylabel('Amplitude (mV)');
grid on;
subplot(2,1,2)
plot(data.("Elapsed Time"), normalForce);
title('Force');
xlabel('Time(s)');
ylabel('Normalized Force');
grid on;

%% 2.1b
% The Number of Segments chosen
numSegments = 5;
segmentLength = floor(length(normalForce) / numSegments);

% Initialization
starts = zeros(1, numSegments);
stops = zeros(1, numSegments);

% Calculating the start and stop indices for each segment
for i = 1:numSegments
    starts(i) = (i - 1) * segmentLength + 1;
    stops(i) = i * segmentLength;
end

stops(end) = length(normalForce);

temp = starts(4);
starts(4) = starts(5);
starts(5) = temp;

temp = stops(4);
stops(4) = stops(5);
stops(5) = temp;

segNo = numSegments;
winSize = 200;

% Table Variables
Force = zeros(segNo,1);
Mean = zeros(segNo,1);
Variance = zeros(segNo,1);
DR = zeros(segNo,1);
MS = zeros(segNo,1);
RMS = zeros(segNo,1);

% Table Rows
rows = cell(segNo, 1); 

for i = 1:segNo
    rows{i} = ['Segment ', num2str(i)]; 
    forceSeg = force(starts(i):stops(i)); 
    EMGSeg = EMG(starts(i):stops(i)); 
    m = mean(forceSeg); 
    feat = STAnalysis(EMGSeg, winSize); 
    mFeat = mean(feat); 
    Force(i) = m;
    Mean(i) = mFeat(1);
    Variance(i) = mFeat(2);
    DR(i) = mFeat(3);
    MS(i) = mFeat(4);
    RMS(i) = mFeat(5);
end

combinedMetrics = [Force, Mean, Variance, DR, MS, RMS];
[~, idx] = sortrows(combinedMetrics);

rows = rows(idx);
Force = Force(idx);
Mean = Mean(idx);
Variance = Variance(idx);
DR = DR(idx);
MS = MS(idx);
RMS = RMS(idx);

b = table(Force, Mean, Variance, DR, MS, RMS, 'RowNames',rows); 

%% 2.1
output = table2array(b);

% Linear Regression done for Mean to Force
fitMean = fitlm(b.Force, b.Mean);
f = plot(fitMean);
f.set("LineWidth",2);
title('Mean vs Force');
xlabel('Force (N)');
ylabel('Mean');
grid on;

%% Linear Regression done for Variance to Force
fitVar = fitlm(b.Force, b.Variance);
f = plot(fitVar);
f.set("LineWidth",2);
title('Variance VS. Force');
xlabel('Force (N)');
ylabel('Variance');
grid on;

%% Linear Regression done for DR to Force
fitDR = fitlm(b.Force, b.DR);
f = plot(fitDR);
f.set("LineWidth",2);
title('Dynamic Range VS. Force');
xlabel('Force (N)');
ylabel('DR');
grid on;

%% Linear Regression done for MS to Force
fitMS = fitlm(b.Force, b.MS);
f = plot(fitMS);
f.set("LineWidth",2);
title('Mean Squared VS. Force');
xlabel('Force (N)');
ylabel('MS');
grid on;

%% Linear Regression done for RMS to Force
fitRMS = fitlm(b.Force, b.RMS);
f = plot(fitRMS);
f.set("LineWidth",2);
title('Root Mean Squared VS. Force');
xlabel('Force (N)');
ylabel('RMS');
grid on;

%% 2.1d
% Residual for Mean
p1 = [0.0005323 0.004187];
x = [34.6189 64.8557 118.7789 133.8206 184.4491];
y1 = polyval(p1,x);
y_true1 = [0.024599 0.039061 0.065783 0.071729 0.10574];
res_mean1 = (y_true - y1);
% Residual for Varience 
p2 = [3.524e-05 0.0003558];
y2 = polyval(p2,x);
y_true2 = [0.0034605 0.0009922 0.0029958 0.0054277 0.0078325];
res_mean2 = (y_true2 - y2);
% Residual for Dynamic Range
p3 = [0.003548 0.05653];
y3 = polyval(p3,x);
y_true3 = [0.20089 0.27696 0.47292 0.50301 0.73522];
res_mean3 = (y_true3 - y3);
% Residual for Mean Squared
p4 = [0.0001167 0.002612];
y4 = polyval(p4,x);
y_true4 = [0.0045847 0.0025751 0.0074788 0.014328 0.020655];
res_mean4 = (y_true4 - y4);
% Residual for Root Mean Squared
p5 = [0.0006632 0.007649];
y5 = polyval(p5,x);
y_true5 = [0.033991 0.049898 0.084988 0.091147 0.13451];
res_mean5 = (y_true5 - y5);
subplot(3,2,1);
bar(res_mean1);
title('Residuals: Mean');
xlabel('Segment');
ylabel('Residuals');
grid on;
subplot(3,2,2);
bar(res_mean2);
title('Residuals: Varience');
xlabel('Segment');
ylabel('Residuals');
grid on;
subplot(3,2,3);
bar(res_mean3);
title('Residuals: DR');
xlabel('Segment');
ylabel('Residuals');
grid on;
subplot(3,2,4);
bar(res_mean4);
title('Residuals: MS');
xlabel('Segment');
ylabel('Residuals');
grid on;
subplot(3,2,5);
bar(res_mean5);
title('Residuals: RMS');
xlabel('Segment');
ylabel('Residuals');
grid on;

%% 2.1e
MSE = [fitMean.MSE;  fitVar.MSE; fitDR.MSE; fitMS.MSE; fitRMS.MSE];% mean sq err
R2 = [fitMean.Rsquared.Ordinary;  fitVar.Rsquared.Ordinary;...
    fitDR.Rsquared.Ordinary; fitMS.Rsquared.Ordinary;...
    fitRMS.Rsquared.Ordinary]; % correlation coeff
R = sqrt(R2);

rows2 = {'Mean', 'Variance', 'Dynamic Range', 'Mean Squared', 'Root Mean Squared'};

e = table(MSE, R, 'RowNames',rows2);
