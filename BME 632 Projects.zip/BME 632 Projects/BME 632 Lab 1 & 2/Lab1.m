%% RESTING PLOT 
filename = 'restingspo2.csv';

data = readtable(filename, 'PreserveVariableNames', true);

t = datevec(data.("Elapsed Time"));
time = (t(:,1).*3.154e+7) + (t(:,2).*2628336.2137829) + (t(:,3).*86410.958906880114228) + (t(:,4).*3600) + (t(:,5).*60) + (t(:,6));
data.("Elapsed Time") = time;

varNames = data.Properties.VariableNames;

heartRateVar = varNames{contains(varNames, 'Heart Rate')};
ppgVar = varNames{contains(varNames, 'PPG')};
spo2Var = varNames{contains(varNames, 'SpO2')};

data = data(data.(heartRateVar) < 100, :);

subplot(3,1,1)
plot(data.("Elapsed Time"), data.(heartRateVar));
grid on;
title('Heart Rate vs Time');
xlabel('Time (s)');
ylabel('Heart Rate (bpm)');
axis([0 20 0 100]);

subplot(3,1,2)
plot(data.("Elapsed Time"), data.(ppgVar));
grid on;
title('PPG vs Time');
xlabel('Time (s)');
ylabel('PPG');
axis([0 20 75 90]);

subplot(3,1,3)
plot(data.("Elapsed Time"), data.(spo2Var));
grid on;
title('SpO2 vs Time');
xlabel('Time (s)');
ylabel('SpO2 (%)');
axis([0 20 85 100]);

sgtitle('RESTING');

d = data(:,2:4);
d = table2array(d);

varname = {'Heart Rate', 'PPG', 'SpO2'};
rowname = {'Mean', 'Standard Deviation'};

m = mean(d);
s = std(d);
arr = [m; s];

answer = table(arr(:,1), arr(:,2), arr(:,3), 'VariableNames', varname, 'RowNames', rowname);
disp(answer);


%% HOLDING PLOT
filename = 'holdingspo2.csv';

data = readtable(filename, 'PreserveVariableNames', true);

t = datevec(data.("Elapsed Time"));
time = (t(:,1).*3.154e+7) + (t(:,2).*2628336.2137829) + (t(:,3).*86410.958906880114228) + (t(:,4).*3600) + (t(:,5).*60) + (t(:,6));
data.("Elapsed Time") = time;

varNames = data.Properties.VariableNames;

heartRateVar = varNames{contains(varNames, 'Heart Rate')};
ppgVar = varNames{contains(varNames, 'PPG')};
spo2Var = varNames{contains(varNames, 'SpO2')};

subplot(3,1,1)
plot(data.("Elapsed Time"), data.(heartRateVar));
grid on;
title('Heart Rate vs Time');
xlabel('Time (s)');
ylabel('Heart Rate (bpm)');
axis([0 70 0 100]);

subplot(3,1,2)
plot(data.("Elapsed Time"), data.(ppgVar));
grid on;
title('PPG vs Time');
xlabel('Time (s)');
ylabel('PPG');
axis([0 70 75 90]);

subplot(3,1,3)
plot(data.("Elapsed Time"), data.(spo2Var));
grid on;
title('SpO2 vs Time');
xlabel('Time (s)');
ylabel('SpO2 (%)');
axis([0 70 85 100]);

sgtitle('HOLDING');

d = data(:,2:4);
d = table2array(d);

varname = {'Heart Rate', 'PPG', 'SpO2'};
rowname = {'Mean', 'Standard Deviation'};

m = mean(d);
s = std(d);
arr = [m; s];

answer = table(arr(:,1), arr(:,2), arr(:,3), 'VariableNames', varname, 'RowNames', rowname);
disp(answer);


%% BP  
% Relaxed
filename = 'relaxed.csv';
data = readtable(filename, 'PreserveVariableNames', true);

t = datevec(data.("Elapsed Time"));
time = (t(:,1).*3.154e+7) + (t(:,2).*2628336.2137829) + (t(:,3).*86410.958906880114228) + (t(:,4).*3600) + (t(:,5).*60) + (t(:,6));
data.("Elapsed Time") = time;

% Exercising
filename1 = 'exercise.csv';
data1 = readtable(filename1, 'PreserveVariableNames', true);

t1 = datevec(data1.("Elapsed Time"));
time1 = (t1(:,1).*3.154e+7) + (t1(:,2).*2628336.2137829) + (t1(:,3).*86410.958906880114228) + (t1(:,4).*3600) + (t1(:,5).*60) + (t1(:,6));
data1.("Elapsed Time") = time1;

varNames = data.Properties.VariableNames;

bpVar = varNames{contains(varNames, 'Blood Pressure')};
ppgVar = varNames{contains(varNames, 'PPG')};

subplot(4,1,1)
plot(data.("Elapsed Time"), data.(bpVar));
title('Blood Pressure - Relaxed');
xlabel('Time (s)');
ylabel('Blood Pressure (mmHg)');
subplot(4,1,2)
plot(data.("Elapsed Time"), data.(ppgVar));
title('PPG - Relaxed');
xlabel('Time (s)');
ylabel('PPG');
axis([8 13 50 140]);

varNames1 = data1.Properties.VariableNames;

bpVar1 = varNames1{contains(varNames1, 'Blood Pressure')};
ppgVar = varNames{contains(varNames, 'PPG')};

subplot(4,1,3)
plot(data1.("Elapsed Time"), data1.(bpVar1));
title('Blood Pressure - Exercise');
xlabel('Time (s)');
ylabel('Blood Pressure (mmHg)');
subplot(4,1,4)
plot(data1.("Elapsed Time"), data1.(ppgVar));
title('PPG - Exercise');
xlabel('Time (s)');
ylabel('PPG');
axis([10.5 20 60 160]);

sgtitle('Blood Pressure Measurement'); 






