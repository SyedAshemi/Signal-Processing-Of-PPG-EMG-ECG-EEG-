function output = STAnalysis(input, win_size)
    output = zeros(length(input),5);
    data = [input; zeros(win_size,1)];
    for k = 1:length(input)
        win = data(k:(k+win_size));
        Mean = mean(abs(win));
        Var = var(abs(win));
        DR = max(win)-min(win);
        RMS = rms(abs(win));
        MS = RMS^2;
        output(k,:) = [Mean, Var, DR, MS, RMS];
    end
end