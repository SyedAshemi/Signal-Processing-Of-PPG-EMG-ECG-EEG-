% Experiment 2- Grasp Force Measurement
filename = 'GraspForce.csv';
data = readtable(filename, 'PreserveVariableNames', true);
data = removevars(data, 'BioRadio Event');
freq = 1000;
time = 0:(1/freq):((size(data)-1)/freq);
time = time.';
data.("Elapsed Time") = time;

EMG = data.Finger;
force = data.("Grip Strength Force");

% normalized force
normalForce = (force-min(force))./(max(force)-min(force));
for i = 1:length(normalForce)
    if normalForce(i) < 0.06
        normalForce(i) = 0;
    end
end

% segmentation
nF = zeros(length(normalForce),1);
for i = 1:length(normalForce)
    if normalForce(i) > 0.06
        nF(i) = 1;
    end
end

mask = logical(nF(:).');    %(:).' to force row vector
starts = strfind([false, mask], [0 1]);
stops = strfind([mask, false], [1 0]);


% list of window sizes in seconds
windowSizes = linspace(0.02,2,20);
% convert window sizes to number of samples
winSizes = windowSizes*freq;
winSizes = round(winSizes);
segNo = length(starts);

%% iterated analysis over window sizes

meanR2 = zeros(length(winSizes),1);
varR2 = zeros(length(winSizes),1);
drR2 = zeros(length(winSizes),1);
msR2 = zeros(length(winSizes),1);
rmsR2 = zeros(length(winSizes),1);

for i = 1:length(winSizes)
    % select windows size
    winSize = winSizes(i);

    % Table Variables
    Force = zeros(segNo,1);
    Mean = zeros(segNo,1);
    Variance = zeros(segNo,1);
    DR = zeros(segNo,1);
    MS = zeros(segNo,1);
    RMS = zeros(segNo,1);
    % Table Rows
    rows = {'Segment 1', 'Segment 2', 'Segment 3', 'Segment 4', 'Segment 5'};
    
    % avg STA for each segment
    for j = 1:segNo
        forceSeg = force(starts(j):stops(j)); %segment of the force data
        EMGSeg = EMG(starts(j):stops(j)); %segment of the emg data
        m = mean(forceSeg); % avg force in selected segment
        feat = STAnalysis(EMGSeg, winSize); % STA of selected emg segment
        mFeat = mean(feat); % avg of STA
        Force(j) = m;
        Mean(j) = mFeat(1);
        Variance(j) = mFeat(2);
        DR(j) = mFeat(3);
        MS(j) = mFeat(4);
        RMS(j) = mFeat(5);
    end
    % linear regression for each of the metrics
    fitMean = fitlm(Force, Mean);
    fitVar = fitlm(Force, Variance);
    fitDR = fitlm(Force, DR);
    fitMS = fitlm(Force, MS);
    fitRMS = fitlm(Force, RMS);
    % assigning r2 value for each metric to array
    meanR2(i) = fitMean.Rsquared.Ordinary;
    varR2(i) = fitVar.Rsquared.Ordinary;
    drR2(i) = fitDR.Rsquared.Ordinary;
    msR2(i) = fitMS.Rsquared.Ordinary;
    rmsR2(i) = fitRMS.Rsquared.Ordinary;
end

%%
plot(windowSizes, meanR2, 'Color', "#7E2F8E", 'LineWidth',1);
hold on
plot(windowSizes, msR2, 'm', 'LineWidth',1);
hold on
plot(windowSizes, rmsR2, 'Color', "#77AC30", 'LineWidth',1);
title('R^2 vs STA window size');
xlabel('Window Sizes (s)');
ylabel('R^2');
legend('Mean', 'Mean Squared','Root Mean Squared');
grid on;
hold off

